module.exports = async function(req, res) {
    const query = req.query.q;
    
    if (!query) {
        return res.status(400).json({ error: 'Query is required' });
    }

    const apiKey = process.env.YOUTUBE_API_KEY; 
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=8&q=${encodeURIComponent(query)}&type=video&key=${apiKey}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        
        // Forward YouTube security/quota errors to the frontend
        if (data.error) {
            return res.status(400).json({ error: data.error });
        }

        res.setHeader('Access-Control-Allow-Origin', '*');
        res.status(200).json(data);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch from YouTube server' });
    }
};
